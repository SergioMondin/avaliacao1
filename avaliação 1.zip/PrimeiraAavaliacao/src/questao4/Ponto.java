package questao4;

public class Ponto {
 
	private double x,y;
	
	public Ponto(double x, double y){
		this.x = x;
		this.y = y;
	}
	public double getDistancia(Ponto p) {
		double distancia=0;
		distancia = Math.sqrt(Math.pow(p.x - this.x,2) + Math.pow(p.y - this.y ,2));
		return distancia;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Ponto [x=").append(x).append(", y=").append(y)
				.append("]");
		return builder.toString();
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
}
