package questao1;

import java.text.ParseException;


public class Main {

	/**
	 * @param args
	 * @throws ParseException
	 */
	public static void main(String[] args) throws ParseException {

		Exercicio01 ex01 = new Exercicio01("16/04/2013");
		ex01.RetornaDigitosAno("16/04/2013");
		ex01.CalculaData("15/04/2013");
		// TODO Auto-generated method stub

	}

}
