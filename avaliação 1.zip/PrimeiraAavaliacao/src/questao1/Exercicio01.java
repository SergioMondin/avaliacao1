package questao1;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class Exercicio01 {
	String Data;

	public Exercicio01(String nData) {

		this.Data = setData(nData);
	}

	public String setData(String Data) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		GregorianCalendar calendar = new GregorianCalendar();
		Date DataHoje = new Date(System.currentTimeMillis());
		String data = formatter.format(DataHoje);
		return data;

	}

	public void CalculaData(String Data) throws ParseException {
		SimpleDateFormat fr = new SimpleDateFormat("dd/MM/yyyy");
		//String cData = fr.format(Data);
		//System.out.println(cData);
		String sData = Data.substring(6);
		int vData = Integer.parseInt(sData);
		int cValor;
		int cAno;
		int DivAno;
		int cMes;
		int Soma;
		int result;
		if (vData > 1700 && vData < 2099)
		{
			cValor = ReturnC(vData);
			cAno = Integer.parseInt(RetornaDigitosAno(Data));
			DivAno = (int)(cAno/4);
			String fff = RetornaMes(Data);
			cMes = Integer.parseInt(fff);
			String cDia = Data.substring(0, 2);
			int vDia = Integer.parseInt(cDia);
			Soma = cValor + cAno + DivAno + cMes + vDia;
			result = (int)Soma%7;
			MostraDiaSemana(result);
		}

	}

	public int ReturnC(int v)
		{
			if(v >= 1700 && v < 1800)
			{
				v = 4;
			}

			if(v >= 1800 && v < 2000)
			{
				v = 0;
			}

			if(v >= 2000)
			{
				v = 6;
			}
			return v;

		}

	public String RetornaDigitosAno(String Data)
	{
		String xxAno = Data.substring(8);
		return (xxAno);

	}

	public String RetornaMes(String Data)
	{
		String retorna;
		boolean bissesto = false;
		String vAno = Data.substring(6);
		int tAno = Integer.parseInt(vAno);
		String fData = Data.substring(3, 5);
		if(tAno % 4 == 0 && (tAno % 100 != 0 || tAno % 400 == 0))
		{
			bissesto = true;
		}
		retorna = fData;
		if(fData.equals("01") || fData.equals("10"))
		{
			retorna = "0";
		}

		if(fData.equals("01"))
		{
			retorna = "1";
		}

		if((fData.equals("02") && bissesto == true ) || fData.equals("08"))
		{
			retorna = "2";
		}

		if (fData.equals("02") || fData.equals("03") || fData.equals("11"))
		{
			retorna = "3";
		}

		if (fData.equals("06"))
		{
			retorna = "4";
		}

		if (fData.equals("09") || fData.equals("12"))
		{
			retorna = "5";
		}

		if((fData.equals("01") && bissesto == true) || fData.equals("04") || fData.equals("07"))
		{
			retorna = "6";
		}

		return retorna;
	}

	public void MostraDiaSemana(int resultado)
	{
		if (resultado == 0)
		{
			System.out.println("Domingo");
		}
		if (resultado == 1)
		{
			System.out.println("Segunda");
		}
		if (resultado == 2)
		{
			System.out.println("Ter�a");
		}
		if (resultado == 3)
		{
			System.out.println("Quarta");
		}
		if (resultado == 4)
		{
			System.out.println("Quinta");
		}
		if (resultado == 5)
		{
			System.out.println("Sexta");
		}
		if (resultado == 6)
		{
			System.out.println("S�bado");
		}

	}

	}

