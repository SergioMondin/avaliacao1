package questao3;

public class Produto {

	private String descricao;
	private double valorBase;
	private double valorTaxas;
	private double valorFinal;
	
	
	public Produto(String descricao,double valor){
		this.descricao = descricao;
		this.valorBase = valor;
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValorBase() {
		return valorBase;
	}
	public void setValorBase(double valorBase) {
		this.valorBase = valorBase;
	}
	public double getValorTaxas() {
		return valorTaxas;
	}
	public void setValorTaxas(double valorTaxas) {
		this.valorTaxas = valorTaxas;
	}
	public double getValorFinal() {
		return valorFinal;
	}
	public void setValorFinal(double valorFinal) {
		this.valorFinal = valorFinal;
	}
	
	public void sobreTaxa() {
		if(this.valorFinal > 4000){
			this.valorTaxas = (this.valorBase * (3/100));
			this.valorFinal = this.valorFinal + (this.valorBase * (3/100));
		}
		
	}
}
