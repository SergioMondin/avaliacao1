package questao3;

import questao2.Calculos;

public class ProdutoEspecial extends Produto {

	public ProdutoEspecial(String descricao, double valor) {
		super(descricao, valor);
		
		calculaTaxa();
		sobreTaxa();
		this.setValorFinal(this.getValorBase() + this.getValorTaxas());
		
		// TODO Auto-generated constructor stub
	}

	public void calculaTaxa() {
		if(this.getValorBase() * (8/100) > 143){
		this.setValorTaxas(this.getValorBase() * (8/100));
		}
		else{
			this.setValorTaxas(143);
		}
	}
	
}
