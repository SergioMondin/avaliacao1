package questao3;

public class ProdutoComum extends Produto{

	public ProdutoComum(String descricao, double valor) {
		super(descricao, valor);
		calculaTaxa();
		sobreTaxa();
		this.setValorFinal(this.getValorBase() + this.getValorTaxas());
		// TODO Auto-generated constructor stub
	}

	public void calculaTaxa() {
		
		this.setValorTaxas(this.getValorBase() * (11/100));
		
	}
}
